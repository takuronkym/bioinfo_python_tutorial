for i in range(3):
    print("Hello, world!")
    